package ar.org.centro8.test;

import java.io.FileReader;

public class TestExceptions {
    public static void main(String[] args) {
        //System.out.println(10/0);
        //System.out.println("Esta sentencia no se ejecuta!");

        /*
         * Estructura try catch finally
         * 
         * try{                                     //obligatorio
         * 
         *      //colocar aquí las sentencias que puedan arrojar un error (exception).
         *      //si se puede ejecutar sin problemas, termina el control del bloque 
         *      // y continua el control en finally o después de la estructura.
         *      //Si ocurre una exception, se corta el control de bloque y continua
         *      //el control en el bloque catch sin detener la ejecución del programa.
         *      //Estas sentencias tienen mayor costo de hardware.
         * 
         * }catch(Exception e){                     //obligatorio
         * 
         *      //Este bloque se ejecuta unicamente si ocurrio exception en try.
         *      //Se recibe como parámetro un objeto de Exception con los detalles
         *      //del error ocurrido.
         *      //El bloque termina y continua el control en finally o después de
         *      // la estructura.
         * 
         * }finally{                                //opcional
         *                               
         *      //Este bloque se ejecuta siempre, exista exception o no.
         *      //No hay scoped(alcance) a las variables declaradas en try o catch.
         * 
         * }
         * 
         *  //el programa termina normalmente.
         */

         /*
        try {
            System.out.println(10/1);
            System.out.println("Esta sentencia no se ejecuta!");
        } catch (Exception e) {
            System.out.println("Ocurrio un error!");
            System.out.println(e);
        } finally {
            System.out.println("Este bloque se ejecuta siempre!");
        }
        System.out.println("El programa termina normalmente!");
        */

        try {
            //GeneradorExceptions.generar();
            //GeneradorExceptions.generar(true);
            //GeneradorExceptions.generar("26x");
            //GeneradorExceptions.generar(null, 0);
            //GeneradorExceptions.generar("hola",20);
            //FileReader in=new FileReader("texto.txt");
        } catch (Exception e) {
            System.out.println(e);
        }



    }
}
