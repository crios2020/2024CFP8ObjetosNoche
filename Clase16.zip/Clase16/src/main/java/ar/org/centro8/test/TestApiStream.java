package ar.org.centro8.test;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import ar.org.centro8.entities.Persona;

public class TestApiStream {
    public static void main(String[] args) {
        List<Persona>personas=new ArrayList();
        personas.add(new Persona("Juan","Perez",32));
        personas.add(new Persona("Laura","Gomez",41));
        personas.add(new Persona("Mario","Sosa",23));
        personas.add(new Persona("Laura","Martinez",54));
        personas.add(new Persona("Lara","Trote",33));

        System.out.println("***********************************************");
        //select * from personas;
        personas.stream().forEach(System.out::println);

        System.out.println("***********************************************");
        //select * from personas where nombre="laura";
        personas
                .stream()
                .filter(persona->persona
                                        .getNombre()
                                        .equalsIgnoreCase("laura"))
                .forEach(System.out::println);

        System.out.println("***********************************************");
        //select * from personas where nombre like 'la%';
        personas
                .stream()
                .filter(persona->persona
                                        .getNombre()
                                        .toLowerCase()
                                        .startsWith("la"))
                .forEach(System.out::println);

        System.out.println("***********************************************");
        //select * from personas where nombre like '%a';
        personas
                .stream()
                .filter(persona->persona
                                        .getNombre()
                                        .toLowerCase()
                                        .endsWith("a"))
                .forEach(System.out::println);
        
        System.out.println("***********************************************");
        //select * from personas where nombre like '%ar%';
        personas
                .stream()
                .filter(persona->persona
                                        .getNombre()
                                        .toLowerCase()
                                        .contains("ar"))
                .forEach(System.out::println);
        
        System.out.println("***********************************************");
        //select * from personas where nombre ='laura' and apellido='perez';
        personas
        .stream()
        .filter(persona->persona
                                .getNombre()
                                .equalsIgnoreCase("laura")
                        &&
                        persona
                                .getApellido().equalsIgnoreCase("perez"))
        .forEach(System.out::println);

        System.out.println("***********************************************");
        //select * from personas where nombre ='laura' or apellido='perez';
        personas
                .stream()
                .filter(persona->persona
                                .getNombre()
                                .equalsIgnoreCase("laura")
                        ||
                        persona
                                .getApellido().equalsIgnoreCase("perez"))
        .forEach(System.out::println);


        System.out.println("***********************************************");
        //select * from personas where edad between 30 and 40;
        personas
                .stream()
                .filter(persona->       persona.getEdad()>=30
                        &&              persona.getEdad()<=40
                )
                .forEach(System.out::println);

        System.out.println("***********************************************");
        //select * from personas order by nombre;
        personas
                .stream()
                .sorted(Comparator.comparing(Persona::getNombre))
                .forEach(System.out::println);
        
        
        System.out.println("***********************************************");
        //select * from personas where nombre like '%a' order by nombre;
        personas
                .stream()
                .filter(persona->persona.getNombre().toLowerCase().endsWith("a"))
                .sorted(Comparator.comparing(Persona::getNombre))
                .forEach(System.out::println);
        
        System.out.println("***********************************************");
        //select * from personas where nombre like '%a' order by nombre desc;
        personas
                .stream()
                .filter(persona->persona.getNombre().toLowerCase().endsWith("a"))
                .sorted(Comparator.comparing(Persona::getNombre).reversed())
                .forEach(System.out::println);

        System.out.println("***********************************************");
        //select * from personas order by apellido, nombre;
        personas
                .stream()
                .sorted(Comparator.comparing(Persona::getApellido)
                        .thenComparing(Persona::getNombre))
                .forEach(System.out::println);

        //personas
        //        .stream()
        //        .sorted(Comparator.comparing(Persona::getNombre))
        //        .sorted(Comparator.comparing(Persona::getApellido))
        //        .forEach(System.out::println);

        System.out.println("***********************************************");
        //select max(edad) from personas;
        int edadMaxima=personas
                .stream()
                .max(Comparator.comparingInt(Persona::getEdad))
                .get()
                .getEdad();
        System.out.println("Edad Máxima: "+edadMaxima);

        System.out.println("***********************************************");
        //select * from personas where edad = (select max(edad) from personas);
        personas
                .stream()
                .filter(persona->persona.getEdad()==edadMaxima)
                .forEach(System.out::println);
                


    }
}
