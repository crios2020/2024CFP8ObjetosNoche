public class Clase03{
    public static void main(String[] args) {
        System.out.println("Clase 03 Paradigma de Objetos");

        //https://codeshare.io/crios2020

        /*
         * Paradigma de la Programación Orientada a Objetos
         * 
         * Clase: una clase representa cosas sustantivas y concretas
         *          de la realidad de un negocio. Las clases se 
         *          identifican en singular y la primer letra en 
         *          mayúsculas.
         * 
         * 
         * Atributos: son adjetivos que describen a la clase.
         *            son variables contenidas dentro de una clase
         *            y pertenecen a un tipo primitivo.
         * 
         * Métodos:   son acciones que realiza la clase, y se detectan
         *            como verbos.
         * 
         * 
         * Objetos:   son instancia de la clase y representan una situación
         *              en particular.
         *            Los objetos tienen un estado propio, el estado es el 
         *              valor de sus atributos.
         * 
         * Sobrecarga de métodos: ocurre cuando en una misma clase
         *          existen métodos con el mismo nombre, pero
         *          con diferente firma de parámetros de entrada.
         * 
         * Método constructor: es un método que tiene el mismo
         *          nombre que la clase, no tiene devolución de
         *          valor, se ejecuta automáticamente al construir
         *          un objeto y realiza las acciones necesarias
         *          para inicializar un objeto.
         *          Los constructores pueden sobrecargarse.
         *          y si la clase no tiene constructor, Java agrega
         *          un constructor vacio en tiempo de compilación
        */

        System.out.println("-- auto1 --");
        Auto auto1=new Auto();      //new Auto() constructor

        auto1.marca="Ford";
        auto1.modelo="Ka";
        auto1.color="Negro";
        auto1.acelerar();           //10
        auto1.acelerar();           //20
        auto1.acelerar();           //30
        auto1.frenar();             //20
        auto1.acelerar(18);     //38
        auto1.acelerar(27);     //65

        System.out.println(auto1.marca+" "+auto1.modelo+" "+
                            auto1.color+" "+auto1.velocidad);
        
        System.out.println("-- auto2 --");
        Auto auto2 = new Auto();
        auto2.marca="Fiat";
        auto2.modelo="Idea";
        auto2.color="Rojo";

        for(int a=0; a<=60; a++) {
            auto2.acelerar();
        }

        System.out.println(auto2.marca+" "+auto2.modelo+" "+
                            auto2.color+" "+auto2.velocidad);
        //System.out.println(auto2);

        System.out.println("-- auto3 --");
        Auto auto3=new Auto("VW","Gol","Azul");
        auto3.acelerar(26);

        auto3.imprimirVelocidad();
        System.out.println(auto3.obtenerVelocidad());

        //método toString()
        System.out.println(auto3.toString());
        System.out.println(auto3);
        
        System.out.println("-- empleado1 --");
        Empleado empleado1=new Empleado(
                1, 
                "Ana", 
                "Garcia", 
                333333);
        System.out.println(empleado1);



    }
}