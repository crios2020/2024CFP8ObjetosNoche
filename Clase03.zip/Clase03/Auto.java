//declaración de clase
public class Auto {
    
    //atributos
    String marca;
    String modelo;
    String color;
    int velocidad;

    //constructores

    /**
     * Método deprecado por Carlos Rios por resultar inseguro.
     * fecha: 15/03/2024, usar en su reemplazo
     * Auto(String marca, String modelo, String color)
     */
    @Deprecated
    Auto(){} //constructor vacio

    Auto(String marca, String modelo, String color){
        this.marca=marca;
        this.modelo=modelo;
        this.color=color;
    }


    //métodos
    void acelerar(){
        //velocidad+=10;
        //if(velocidad>100) velocidad=100;
        acelerar(10);   //llamado a método dentro de la misma clase
    }

    /**
     * 
     * @param kilometros cantidad de kilometros a aumentar la velocidad
     */
    void acelerar(int kilometros){
        velocidad+=kilometros;
        if(velocidad>100) velocidad=100;
    }

    void frenar(){
        velocidad-=10;
    }

    //método sin valor de retorno
    void imprimirVelocidad(){
        System.out.println(velocidad);
    }

    //método con valor de retorno
    int obtenerVelocidad(){
        return velocidad;
    }

    @Override
    public String toString(){
        return marca+" "+modelo+" "+color+" "+velocidad;
    }

}//end class
