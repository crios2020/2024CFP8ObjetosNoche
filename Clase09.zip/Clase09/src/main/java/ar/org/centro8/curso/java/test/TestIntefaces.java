package ar.org.centro8.curso.java.test;

import java.util.Scanner;

import ar.org.centro8.curso.java.interfaces.I_File;
import ar.org.centro8.curso.java.utils.FileBinary;
import ar.org.centro8.curso.java.utils.FileCloud;
import ar.org.centro8.curso.java.utils.FileText;

public class TestIntefaces {
    public static void main(String[] args) throws Exception{
        I_File file=null;

        //file=new FileText();
        //file=new FileBinary();
        //file=new FileCloud();

        System.out.println("Ingrese 'FileText' 'FileBinary' 'FileCloud'");
        String in=new Scanner(System.in).nextLine();

        //if(in.equals("FileText"))       file=new FileText();
        //if(in.equals("FileBinary"))     file=new FileBinary();
        //if(in.equals("FileCloud"))      file=new FileCloud();
    
        file=(I_File)Class
                            .forName("ar.org.centro8.curso.java.utils."+in)
                            //.newInstance();     //Deprecado
                            .getConstructor(null)
                            .newInstance(null);

        //App
        file.setText("Hola");
        System.out.println(file.getText());
        file.info();
        
    }
}
