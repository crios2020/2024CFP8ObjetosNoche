package ar.org.centro8.curso.java.interfaces;

public interface I_File {
    
    /*
     * Que una interface en Java?
     * - Las interfaces no tienen constructores o atributos de objetos.
     * - Todos los miembros de una interface son public.
     * - Los métodos de una interface son abstractos.
     * - Puede contenter atributos final o static.
     * 
     * - Una clase puede implementar todas las interfaces que necesite.
     * 
     */

    /**
     * Este método escribe el archivo.
     * @param text texto a escribir
     */
    void setText(String text); 

    /**
     * Este método lee el archivo
     * @return texto retornado
     */
    String getText();
    
    //Métodos default jdk 8 o sup
    default void info(){
        System.out.println("Interface I_File");
    }

}
