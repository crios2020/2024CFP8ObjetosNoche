package ar.org.centro8.curso.java.entities;

import lombok.Getter;

@Getter
public class Cliente extends Persona {
    private int nroCliente;
    private Cuenta cuenta;

    public Cliente(String nombre, int edad, 
            Direccion direccion, int nroCliente, Cuenta cuenta) {
        super(nombre, edad, direccion);
        this.nroCliente = nroCliente;
        this.cuenta = cuenta;
    }

    @Override
    public String toString() {
        return super.toString()+" Cliente [nroCliente=" + nroCliente + ", cuenta=" + cuenta + "]";
    }

    @Override
    public void saludar(){
        System.out.println("Hola soy un Cliente!");
    }
}
