package ar.org.centro8.curso.java.clase04;

public class Clase04 {
    public static void main(String[] args) {
        System.out.println("Clase 04");

        System.out.println("-- empleado1 --");
        Empleado empleado1=new Empleado(
                        1,
                        "Ana", 
                        "Garcia",
                        350000);
        //empleado1.sueldoBasico=999999999;
        empleado1.setSueldoBasico(999999999);
        System.out.println(empleado1);

        Auto auto1=new Auto(
            "Ford", 
            "Ka", 
            "Rojo", 
            0);
        auto1.acelerar(34);
        System.out.println(auto1);
        

    }
}
