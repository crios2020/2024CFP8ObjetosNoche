package ar.org.centro8.curso.java.entities;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@ToString
@Getter
@AllArgsConstructor
public abstract class Persona {
    private String nombre;
    private int edad;
    private Direccion direccion;

    //public void saludar(){
    //    System.out.println("Hola soy una persona!");
    //}

    public abstract void saludar();
}
