package ar.org.centro8.curso.java.test;

import java.text.DecimalFormat;

import ar.org.centro8.curso.java.entities.Circulo;
import ar.org.centro8.curso.java.entities.Figura;
import ar.org.centro8.curso.java.entities.Rectangulo;
import ar.org.centro8.curso.java.entities.Triangulo;

public class TestPolimorfismo {
    public static void main(String[] args) {
        Figura figura=null;

        //figura=new Rectangulo(100, 120);
        figura=new Triangulo(100,120);
        //figura=new Circulo(100);

        //app
        DecimalFormat df=new DecimalFormat("0.00");
        System.out.println("Perimetro: "+df.format(figura.getPerimetro()));
        System.out.println("Superficie: "+df.format(figura.getSuperficie()));
        System.out.println(figura.getEstado());


        //reflectividad
        /*
         * Que es una clase: una clase se encuentra como sustantivos en la vida real, 
         *      se escribe en singular iniciando en mayúscula. Ej Auto, Alumno, Profesor, Vendedor, Articulo
         * Clases en Java: son instancias de la clase java.lang.Class
         * 
         * 
         * Que son los atributos: los atributos son variables contenidas dentro de la clase y 
         *      describen a la clase, tienen un tipo de datos.
         * Atributos en Java: son instancias de la clase java.lang.reflect.Field
         * 
         * Que son los métodos: los métodos son acciones que realiza una clase y se expresan como verbos
         * Métodos en Java: son instancias de la clase java.lang.reflect.Method
         * 
         * Que son los objetos: son instancias de la clase que representan una situación en particular
         *      y tienen estado propio.
         * 
         * Desacoplamiento(deseado) y cohesión de clases(deseado) 
         * Acoplamniento(no deseado)
         * 
         * Constructores: son métodos que se usan para inicializar un objeto, pueden existir varios
         *      constructores sobrecargados, Tienen el nombre nombre que la clase, no tiene devolución de valor.
         *      Si la clase no tiene constructor, java agrega un constructor vacio en tiempo de compilación
         * constructores en java: son instancias de la clase java.lang.reflect.Constructor
         * 
         */

        System.out.println(figura.getClass());
        System.out.println(figura.getClass().getName());
        System.out.println(figura.getClass().getSimpleName());
        System.out.println(figura.getClass().getSuperclass());
        System.out.println(figura.getClass().getSuperclass().getName());
        System.out.println(figura
                                    .getClass()
                                    .getSuperclass()
                                    .getSuperclass()
                                    .getName());

        System.out.println(figura
                                    .getClass()
                                    .getSuperclass()
                                    .getSuperclass()
                                    .getSuperclass());

        String texto="Hola";
        System.out.println(texto.getClass().getName());
        System.out.println(texto.getClass().getSuperclass().getName());


        //Interfaces
        

    }
}
