package ar.org.centro8.curso.java.entities;

public class Vendedor extends Persona {
    
    private int nroLegajo;
    private double sueldoBasico;

    public Vendedor(String nombre, int edad, Direccion direccion, int nroLegajo, double sueldoBasico) {
        super(nombre, edad, direccion); //llama al constructor de clase Padre
        this.nroLegajo = nroLegajo;
        this.sueldoBasico = sueldoBasico;
    }

    @Override
    public String toString() {
        return super.toString()+" Vendedor [nroLegajo=" + nroLegajo + ", sueldoBasico=" + sueldoBasico + "]";
    }

    @Override
    public void saludar() {
        System.out.println("Hola soy un vendedor!");
    }

}
