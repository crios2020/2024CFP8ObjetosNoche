package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entities.Cuenta;
import ar.org.centro8.curso.java.entities.Direccion;
import ar.org.centro8.curso.java.entities.Persona;
import ar.org.centro8.curso.java.entities.Vendedor;

public class TestHerencia {
    public static void main(String[] args) {
        
        System.out.println("-- cuenta1 --");
        Cuenta cuenta1=new Cuenta(1,"arg$");
        cuenta1.depositar(250000);
        cuenta1.depositar(100000);
        cuenta1.debitar(180000);
        System.out.println(cuenta1);
        cuenta1.debitar(350000);
        System.out.println(cuenta1);

        System.out.println("-- direccion1 --");
        Direccion direccion1=new Direccion(
                    "Medrano", 
                    162,
                    "1", 
                    "1");
        System.out.println(direccion1);

        System.out.println("-- direccion2 --");
        Direccion direccion2=new Direccion(
                "Belgrano", 
                49, 
                null, 
                null,
                "Moron");
        System.out.println(direccion2);

        // System.out.println("-- persona1 --");
        // Persona persona1=new Persona("Ana",34,direccion1);
        // System.out.println(persona1);
        // persona1.saludar();

        System.out.println("-- vendedor1 --");
        Vendedor vendedor1=new Vendedor(
                            "Mario", 
                            33, 
                            direccion2, 
                            1, 
                            850000);
        System.out.println(vendedor1);
        vendedor1.saludar();
        


    }
}
