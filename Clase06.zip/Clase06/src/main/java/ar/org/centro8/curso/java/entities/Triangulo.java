package ar.org.centro8.curso.java.entities;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@ToString
@Getter
@AllArgsConstructor
public class Triangulo {

    private double base;
    private double altura;

    public double getPerimetro(){
        return 
            base
            +altura
            //+Math.sqrt(Math.pow(base, 2)+Math.pow(altura, 2));
            +Math.hypot(base, altura);
    }

    public double getSuperficie(){
        return base*altura/2;
    }
    
}
