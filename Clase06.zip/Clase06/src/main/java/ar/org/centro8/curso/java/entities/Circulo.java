package ar.org.centro8.curso.java.entities;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@ToString
@Getter
@AllArgsConstructor
public class Circulo {

    private double radio;

    public double getPerimetro(){
        return Math.PI*radio*2;
    }

    public double getSuperficie(){
        return Math.PI*Math.pow(radio, 2);
    }
}
