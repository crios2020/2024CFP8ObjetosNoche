package ar.org.centro8.test;

import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.entities.Persona;

public class TestApiStream {
    public static void main(String[] args) {
        List<Persona>personas=new ArrayList();
        personas.add(new Persona("Juan","Perez",32));
        personas.add(new Persona("Laura","Gomez",41));
        personas.add(new Persona("Mario","Sosa",23));
        personas.add(new Persona("Laura","Martinez",54));
        personas.add(new Persona("Lara","Trote",33));

        System.out.println("***********************************************");
        //select * from personas;
        personas.stream().forEach(System.out::println);

        System.out.println("***********************************************");
        //select * from personas where nombre="laura";
        personas
                .stream()
                .filter(persona->persona
                                        .getNombre()
                                        .equalsIgnoreCase("laura"))
                .forEach(System.out::println);

        System.out.println("***********************************************");
        //select * from personas where nombre like 'la%';
        personas
                .stream()
                .filter(persona->persona
                                        .getNombre()
                                        .toLowerCase()
                                        .startsWith("la"))
                .forEach(System.out::println);

        System.out.println("***********************************************");
        //select * from personas where nombre like '%a';
        personas
                .stream()
                .filter(persona->persona
                                        .getNombre()
                                        .toLowerCase()
                                        .endsWith("a"))
                .forEach(System.out::println);
        
        System.out.println("***********************************************");
        //select * from personas where nombre like '%ar%';
        personas
                .stream()
                .filter(persona->persona
                                        .getNombre()
                                        .toLowerCase()
                                        .contains("ar"))
                .forEach(System.out::println);
        
        System.out.println("***********************************************");
        //select * from personas where nombre ='laura' and apellido='perez';
        personas
        .stream()
        .filter(persona->persona
                                .getNombre()
                                .equalsIgnoreCase("laura")
                        &&
                        persona
                                .getApellido().equalsIgnoreCase("perez"))
        .forEach(System.out::println);

        System.out.println("***********************************************");
        //select * from personas where nombre ='laura' or apellido='perez';
        personas
                .stream()
                .filter(persona->persona
                                .getNombre()
                                .equalsIgnoreCase("laura")
                        ||
                        persona
                                .getApellido().equalsIgnoreCase("perez"))
        .forEach(System.out::println);


        System.out.println("***********************************************");
        //select * from personas where edad between 30 and 40;

    }
}
