package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entities.Cuenta;

public class TestRelaciones {
    public static void main(String[] args) {
        //Objetos MOCKS (Objetos Simulados)

        System.out.println("-- cuenta1 --");
        Cuenta cuenta1=new Cuenta(1,"arg$");
        cuenta1.depositar(250000);
        cuenta1.depositar(100000);
        cuenta1.debitar(180000);
        System.out.println(cuenta1);
        cuenta1.debitar(350000);
        System.out.println(cuenta1);

    }
}
