package ar.org.centro8.curso.java.test;

import java.util.ArrayList;

import ar.org.centro8.curso.java.entities.ClienteEmpresa;
import ar.org.centro8.curso.java.entities.ClientePersona;
import ar.org.centro8.curso.java.entities.Cuenta;

public class TestRelaciones {
    public static void main(String[] args) {
        //Objetos MOCKS (Objetos Simulados)

        System.out.println("-- cuenta1 --");
        Cuenta cuenta1=new Cuenta(1,"arg$");
        cuenta1.depositar(250000);
        cuenta1.depositar(100000);
        cuenta1.debitar(180000);
        System.out.println(cuenta1);
        cuenta1.debitar(350000);
        System.out.println(cuenta1);

        System.out.println("-- clienteConyuge1 --");
        ClientePersona clienteConyuge1=new ClientePersona(
                        1,
                        "Marcela Solos",
                        34,
                        new Cuenta(2,"args")
        );
        clienteConyuge1.getCuenta().depositar(800000);
        clienteConyuge1.getCuenta().depositar(400000);
        System.out.println(clienteConyuge1);

        System.out.println("-- clienteConyuge2 --");
        ClientePersona clienteConyuge2=new ClientePersona(
                        2, 
                        "Raul Ledesma", 
                        35,
                        clienteConyuge1.getCuenta());
        clienteConyuge2.getCuenta().debitar(850000);
        System.out.println(clienteConyuge2);
        System.out.println(clienteConyuge1);

        ClientePersona clientePersona1=new ClientePersona(
                        3, 
                        "Javier Larrosa", 
                        25,
                        3,
                        "arg$");
        clientePersona1.getCuenta().depositar(258000);
        clientePersona1.getCuenta().depositar(357000);
        clientePersona1.getCuenta().debitar(120000);
        System.out.println(clientePersona1);

        System.out.println("-- clienteEmpresa1 --");
        ClienteEmpresa clienteEmpresa1=new ClienteEmpresa(
                        1, 
                        "Todo Limpio SRL", 
                        "Lama 222");
        ArrayList<Cuenta>cuentas=clienteEmpresa1.getCuentas();
        cuentas.add(new Cuenta(10,"arg$"));         //0
        cuentas.add(new Cuenta(11, "Reales"));      //1
        cuentas.add(new Cuenta(12,"U$S"));          //2

        cuentas.get(0).depositar(5000000);
        cuentas.get(0).depositar(7000000);
        cuentas.get(0).debitar(2300000);
        cuentas.get(1).depositar(60000);
        cuentas.get(2).depositar(12000);
        
        System.out.println(clienteEmpresa1);
        


    }
}
