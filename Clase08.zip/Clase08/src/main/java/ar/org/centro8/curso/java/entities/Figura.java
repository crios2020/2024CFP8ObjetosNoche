package ar.org.centro8.curso.java.entities;

public abstract class Figura {
    /**
     * @return retorna el perímetro de la figura.
     */
    public abstract double getPerimetro();
    /**
     * @return retorna la superficie de la figura.
     */
    public abstract double getSuperficie();
    /**
     * @return retorna el estado del objeto.
     */
    public abstract String getEstado();
}
