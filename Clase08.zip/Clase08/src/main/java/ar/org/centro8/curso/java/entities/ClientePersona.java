package ar.org.centro8.curso.java.entities;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class ClientePersona {

    private int nro;
    private String nombre;
    private int edad;
    private Cuenta cuenta;

    //Un cliente se puede crear sin cuenta
    public ClientePersona(int nro, String nombre, int edad){
        this.nro=nro;
        this.nombre=nombre;
        this.edad=edad;
    }

    //Un cliente siempre se crea con una cuenta
    //Una cuenta puede pertenecer a más de un cliente
    public ClientePersona(int nro, String nombre, int edad, 
                Cuenta cuenta){
        this.nro=nro;
        this.nombre=nombre;
        this.edad=edad;
        this.cuenta=cuenta;
    }

    //Un cliente siempre se crea con una cuenta
    //Un cliente solo tiene una cuenta y la cuenta solo pertenece 
    //a una sola persona
    public ClientePersona(int nro, String nombre, int edad,
                int nroCuenta, String moneda){
            this.nro=nro;
            this.nombre=nombre;
            this.edad=edad;
            this.cuenta=new Cuenta(nroCuenta, moneda);
    }

    public void comprar(){
        System.out.println("El cliente realizo una compra!");
    }

}
