package ar.org.centro8.curso.java.clase04;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

//@ToString
//@Getter
//@Setter
@Data
@AllArgsConstructor
public class Auto {
    
    private String marca;
    private String modelo;
    private String color;
    private int velocidad;

    public void acelerar(int kilometros){
        velocidad+=kilometros;
    }

    public void frenar(int kilometros){
        velocidad-=kilometros;
    }

}
