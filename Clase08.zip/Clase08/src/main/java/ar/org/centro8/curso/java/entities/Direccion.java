package ar.org.centro8.curso.java.entities;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@AllArgsConstructor
public class Direccion {
    
    private String calle;
    private int numero;
    private String piso;
    private String depto;
    private String ciudad;

    /**
     * Constructor para direcciones de
     * Ciudad Autónoma de Buenos Aires
     */
    public Direccion(String calle, int numero, String piso, String depto) {
        this.calle = calle;
        this.numero = numero;
        this.piso = piso;
        this.depto = depto;
        this.ciudad = "CABA";
    }

}
