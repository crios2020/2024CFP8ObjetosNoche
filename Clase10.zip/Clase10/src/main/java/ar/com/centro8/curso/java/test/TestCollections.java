package ar.com.centro8.curso.java.test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import ar.com.centro8.curso.java.entities.Auto;

public class TestCollections {
    public static void main(String[] args) {
        System.out.println("Vectores - Arreglos");

        Auto[] autos=new Auto[4];
        autos[0]=new Auto("Fiat","Idea","Rojo");
        autos[1]=new Auto("Ford","Ka","Negro");
        autos[2]=new Auto("Citroen","C4","Rojo");
        autos[3]=new Auto("VW","Gol","Verde");

        //recorrido con indices
        //for(int a=0; a<autos.length; a++){
        //    System.out.println(autos[a]);
        //}

        //recorrido foreach
        for(Auto auto: autos) System.out.println(auto);

        //Inteface List
        List<Auto>lista=new ArrayList();
        lista.add(new Auto("Peugeot","208","Negro"));
        lista.add(new Auto("VW", "Suran", "Gris"));
        for(Auto auto: autos) lista.add(auto);

        System.out.println("*************************************");
        //Recorrido con indices
        //for(int a=0;a<lista.size(); a++){
        //    System.out.println(lista.get(a));
        //}

        //Recorrido forEach
        //for(Auto auto:lista) System.out.println(auto);

        //Método default
        //lista.forEach(auto->System.out.println(auto));
        //lista.forEach(auto->{
        //    System.out.println(auto);
        //    System.out.println("-");
        //});

        lista.forEach(System.out::println);

        //Interface Set
        Set<String> setSemana=null;
        
        //Implementación HashSet:   Es la más veloz, no hay garantia
        //  en el orden de los elementos
        //setSemana=new HashSet();

        //Implementación LinkedHashSet: Almacena elementos en una lista
        //  enlazada, por orden de ingreso
        //setSemana=new LinkedHashSet();

        //Implementación TreeSet:   Almacena elementos en un arbol
        //  balanceado, por orden natural
        setSemana=new TreeSet();

        //app
        setSemana.add("Lunes");
        setSemana.add("Martes");
        setSemana.add("Miércoles");
        setSemana.add("Jueves");
        setSemana.add("Viernes");
        setSemana.add("Sábado");
        setSemana.add("Domingo");
        setSemana.add("Lunes");
        setSemana.add("Lunes");
        setSemana.add("Martes");
        setSemana.forEach(System.out::println);

        //Set<Auto>setAutos=new LinkedHashSet();
        Set<Auto>setAutos=new TreeSet();
        setAutos.add(new Auto("Citroen", "Berlingo", "Bordo"));
        setAutos.add(new Auto("Peugeot", "208", "Negro"));
        setAutos.addAll(lista);
        //setAutos.forEach(System.out::println);
        setAutos.forEach(auto->System.out.println(auto+"\t"+auto.hashCode()));
    
        //TODO Interface Queue

        //TODO Interface Map




    }
}
