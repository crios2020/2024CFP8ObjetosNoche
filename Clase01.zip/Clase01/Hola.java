/**
 * Clase principal del proyecto
 */
public class Hola{
    /**
     * punto de entrada al proyecto
     * @param args argumentos que ingresan por consola
     */
    public static void main(String[] args) {
        System.out.println("Hola Mundo!");
        System.out.println("Versión de Java: "
                    +System.getProperty("java.version"));
        
        //linea de comentarios
        /* 
            Bloque 
            de 
            Comentarios 
        */
        /** 
            JavaDoc 
            Este comentario es visible desde fuera del archivo binario.
            Este comentario debe colocarse delante de la declaración de 
            método o clase.
        */
        //TODO Tarea pendiente

        
        /*
         *      Lenguaje de tipado fuerte:  Java, C++, C#, TypeScript
         *      Lenguaje de tipado debil:   Python, javascript, php
         * 
         *      
         *      Almacenamiento RAM:         volatil         caro            veloz
         *      Almacenamiento Disco Duro:  persistente     economico       lento
         * 
         */

        //Tipo de datos primitivos

        //Tipo de datos enteros

        //Tipo de datos boolean         1 byte
        boolean bo=true;
        System.out.println(bo);

        /*
         *  1
         *  --------
         */
    
        //Tipo de datos byte        1 byte      -128 a 127
        byte by=-100;
        System.out.println(by);

        //Tipo de datos short       2 bytes
        short sh=12000;
        System.out.println(sh);

        //Tipo de datos int         4 bytes
        int in=2000000000;
        System.out.println(in);

        //Tipo de datos long        8 bytes
        long lo=2000000000L;
        System.out.println(lo);


        //Tipo de datos de punto flotante


        

    }
}