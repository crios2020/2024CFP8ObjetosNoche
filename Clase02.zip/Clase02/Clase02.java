public class Clase02{
    public static void main(String[] args) {
        //Tipo de datos enteros

        //Tipo de datos boolean         1 byte
        boolean bo=true;
        System.out.println(bo);

        /*
         *  1
         *  --------
         */
    
        //Tipo de datos byte        1 byte      -128 a 127
        byte by=-100;
        System.out.println(by);

        //Tipo de datos short       2 bytes  signed
        short sh=12000;
        System.out.println(sh);

        //Tipo de datos int         4 bytes
        int in=2000000000;
        System.out.println(in);

        //Tipo de datos long        8 bytes
        long lo=2000000000L;
        System.out.println(lo);

        //Tipo de datos char unicode        2 bytes unsigned
        char ch=65;
        System.out.println(ch);             //A
        ch+=32;             //sumo 32 
        System.out.println(ch);             //a
        System.out.println((int)ch);        //97
        ch='x';
        System.out.println(ch);             //x

        //Tipo de datos de punto flotante
        
        //Tipo de datos float 32 bits
        float fl=5.78f;
        System.out.println(fl);

        //Tipo de datos double 64 bits
        double dl=5.78;
        System.out.println(dl);

        fl=10;
        dl=10;
        System.out.println(fl/3);
        System.out.println(dl/3);

        fl=100;
        dl=100;
        System.out.println(fl/3);
        System.out.println(dl/3);

        //Clase String
        String st="HOLA";
        System.out.println(st);

        //Tipo de datos var JDK 10 o sup
        var var1=5;                     //int
        var1=8;
        //var1="hola";

        var var2=3.25;                  //double
        var var3=3.25d;                 //double
        var var4=3.25f;                 //float
        var var5=5L;                    //long
        var var6="Hola";                //String
        var var7=true;                  //boolean
        var var8="x";                   //String
        var var9='x';                   //char

        funcion(var1);                  //int
        funcion(var2);                  //double
        funcion(var3);                  //double
        funcion(var4);                  //float
        funcion(var5);                  //long
        funcion(var6);                  //String
        funcion(var7);                  //boolean
        funcion(var8);                  //String
        funcion(var9);                  //char

        String texto="Esto es una cadena de texto!";
        System.out.println(texto);
        
        //recorrido manual
        for(int a=0; a<texto.length(); a++){
            System.out.print(texto.charAt(a));
        }
        System.out.println();

        //Imprimir el String en mayúsculas
        for(int a=0; a<texto.length(); a++){
            char car=texto.charAt(a);
            if(car>=97 && car<=122) car-=32;
            System.out.print(car);
        }
        System.out.println();

        //Operador Ternario ?
        for(int a=0; a<texto.length(); a++){
            char car=texto.charAt(a);
            //char resultado=(car>=97 && car<=122)?car-=32:car;
            //System.out.println(car);
            System.out.print((car>=97 && car<=122)?car-=32:car);
        }
        System.out.println();

        //Imprimir texto todo en minúsculas
        for(int a=0; a<texto.length(); a++){
            char car=texto.charAt(a);
            System.out.print((car>=65 && car<=90)?car+=32:car);
        }
        System.out.println();

        System.out.println(texto);
        System.out.println(texto.toLowerCase());
        System.out.println(texto.toUpperCase());


    }//end main

    public static void funcion(String x){
        System.out.println("Parámetro String");
    }
    public static void funcion(boolean x){
        System.out.println("Parámetro boolean");
    }
    public static void funcion(int x){
        System.out.println("Parámetro int");
    }
    public static void funcion(long x){
        System.out.println("Parámetro long");
    }
    public static void funcion(char x){
        System.out.println("Parámetro char");
    }
    public static void funcion(double x){
        System.out.println("Parámetro double");
    }
    public static void funcion(float x){
        System.out.println("Parámetro float");
    }

}//end class